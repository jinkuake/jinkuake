from distutils.core import setup

setup(
    name='nester',#对外模块名称
    version='1.0.0',
    py_modules=['nester'],#发布的模块
    author='jiale',
    author_email='18521093275@163.com',
    url='http://www.headfirstlabs.com',

    description='这是我的第一个发布安装文件'
)